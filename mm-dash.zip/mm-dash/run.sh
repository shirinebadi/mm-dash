#!/bin/bash

python3 models.py &
python3 app.py

wait 100
  
